# Web & Cloud Security Engineer Skill

## Install for one project
Copy the `web-cloud-security` folder into your project's `.claude/skills/` directory so the final path is:

`.claude/skills/web-cloud-security/SKILL.md`

Claude Code can then discover the skill. Its description tells Claude when the skill is relevant.

## Install for your user account
Alternatively, copy the folder to:

`~/.claude/skills/web-cloud-security/SKILL.md`

## Notes
- Keep the YAML frontmatter at the very top of `SKILL.md`.
- `name` should be lowercase and use hyphens.
- `description` should explain what the skill does and when it should be used.
- `CLAUDE.md` can still be used for general project instructions; `SKILL.md` is the skill definition.
